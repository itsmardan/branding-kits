---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
date: {{ .Date }}
image: "images/team/default.png"
jobtitle: "Employee"
linkedinurl: 'https://www.linkedin.com/'
draft: false
weight: 100
promoted: false
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Bibendum arcu vitae elementum curabitur vitae nunc sed. Tortor at risus viverra adipiscing at in.
